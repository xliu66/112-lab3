from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .models import Movie


# def index(request):
#  return HttpResponse("Hello, world. You're at the rentals index.")

# def index(request):
#   movie = Movie.objects.all()
#   return render(request, 'views/index.html',{'movies':movies}) 

def index(request):
    my_dict = {"insert_me": "I am from views.py"}

    
    return render(request, 'views/index.html',context=my_dict)